﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataTable dataTable;
        public Window1()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionString"].ConnectionString;
            connection = new SqlConnection(connectionString);
            adapter = new SqlDataAdapter("SELECT * FROM emp", connection);

            dataTable = new DataTable();
            adapter.Fill(dataTable);

            dataGrid.ItemsSource = dataTable.DefaultView;
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
             try
                {
                    string empId = "7"; // Hard-coded value
                    string empName = "Alice Johnson"; // Hard-coded value
                    string empSalary = "65000.00"; // Hard-coded value
                    string empDepartment = "Engineering"; // Hard-coded value

                    string query = "INSERT INTO emp (emp_id, emp_name, emp_salary, emp_department) VALUES (@empId, @empName, @empSalary, @empDepartment)";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@empId", empId);
                        cmd.Parameters.AddWithValue("@empName", empName);
                        cmd.Parameters.AddWithValue("@empSalary", empSalary);
                        cmd.Parameters.AddWithValue("@empDepartment", empDepartment);

                        connection.Open();
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }

                    MessageBox.Show("Data saved successfully.");

                    // Refresh the DataGrid
                    dataTable.Clear();
                    adapter.Fill(dataTable);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            

        }
    }
}
